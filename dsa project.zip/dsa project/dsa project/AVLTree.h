#pragma once

#ifndef AVLTREE_H
#define AVLTREE_H

#include <iostream>

class Node {
public:
    int key;
    Node* left;
    Node* right;
    int height;

    Node(int key) : key(key), left(nullptr), right(nullptr), height(1) {}
};

class AVLTree {
private:
    Node* root;

    int getHeight(Node* node);
    int getBalanceFactor(Node* node);
    Node* insertNode(Node* node, int key);
    Node* deleteNode(Node* node, int key);
    Node* getMinValueNode(Node* node);
    Node* searchNode(Node* node, int key);
    void inorderTraversal(Node* node);
    void preorderTraversal(Node* node);
    void postorderTraversal(Node* node);
    int calculateHeight(Node* node);
    int calculateDiameter(Node* node, int& height);
    Node* findSuccessor(Node* node);
    Node* findPredecessor(Node* node);

public:
    AVLTree() : root(nullptr) {}
    void insert(int key);
    void remove(int key);
    bool search(int key);
    void inorder();
    void preorder();
    void postorder();
    int height();
    int diameter();
    int findMin();
    int findMax();
    int successor(int key);
    int predecessor(int key);
    Node* rotateRight(Node* y);
    Node* rotateLeft(Node* x);
    Node* balanceNode(Node* node);

};

#endif 
