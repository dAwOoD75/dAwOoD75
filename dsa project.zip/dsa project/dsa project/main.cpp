
#include "AVLTree.h"
#include <iostream>
using namespace std;

int main() {
    AVLTree avlTree;


    int keys[] = { 10, 20, 30, 40, 50, 60 };

    cout << "Inserting keys into the AVL tree: ";
    for (int key : keys) {
        avlTree.insert(key);
        cout << key << " ";
    }
    cout << endl;


    cout << endl << "Inorder traversal after insertions: ";
    avlTree.inorder();

    cout << "Preorder traversal after insertions: ";
    avlTree.preorder();

    cout << "Postorder traversal after insertions: ";
    avlTree.postorder();


    cout << "\nHeight of the AVL tree: " << avlTree.height() << endl;
    cout << "Diameter of the AVL tree: " << avlTree.diameter() << endl;

    cout << "Minimum value in the AVL tree: " << avlTree.findMin() << endl;
    cout << "Maximum value in the AVL tree: " << avlTree.findMax() << endl;


    int searchKeys[] = { 2, 60, 10 };
    for (int key : searchKeys) {
        cout << "Searching for " << key << ": " << (avlTree.search(key) ? "Found" : "Not Found") << endl;
    }


    int findSuccessors[] = { 10, 20, 25 };
    for (int key : findSuccessors) {
        try {
            cout << "Successor of " << key << ": " << avlTree.successor(key) << endl;
        }
        catch (const runtime_error& e) {
            cerr << e.what() << endl;
        }
    }

    int findPredecessors[] = { 30, 40, 50 };
    for (int key : findPredecessors) {
        try {
            cout << "Predecessor of " << key << ": " << avlTree.predecessor(key) << endl;
        }
        catch (const runtime_error& e) {
            cerr << e.what() << endl;
        }
    }


    avlTree.remove(50);
    cout << endl << "Inorder traversal after deleting 50: ";
    avlTree.inorder();

    cout << "Preorder traversal after deleting 50: ";
    avlTree.preorder();


    Node* root = new Node(30);
    root->left = new Node(20);
    root->right = new Node(40);
    root->left->left = new Node(10);

    cout << endl << "Original small tree (preorder): 30 20 10 40" << endl;


    root = avlTree.rotateRight(root);
    cout << "Tree after right rotation on root (preorder): 20 10 30 40" << endl;


    root->right = new Node(30);
    root->right->right = new Node(40);

    root = avlTree.rotateLeft(root);
    cout << "Tree after left rotation on new root (preorder): 30 20 10 40" << endl;


    root->left = new Node(20);
    root->left->left = new Node(10);


    root = avlTree.balanceNode(root);
    cout << "Tree after balancing (preorder): 20 10 30 40" << endl;


    delete root->left->left;
    delete root->left;
    delete root->right;
    delete root;

    return 0;
}